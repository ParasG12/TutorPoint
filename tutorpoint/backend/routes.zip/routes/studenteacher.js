const express=require('express');
const Router=express.Router();
const db=require('../db');
Router.post('/studentteachers/:id',(request,response)=>{
const {id}=request.params;
const {tid}=request.body;
const statement=`insert into studentteachers values(${id},${tid})`;
db.execute(statement,(error,data)=>{
    if(error){
        response.status(400).send({message:'data not inserted'});
    }
    else{
        response.status(200).send({message:'data inserted success'});
    }
})
})
Router.get('/student/filter/:id',(request,response)=>{
    const {id}=request.params;
    const statement=`select * from teachers where id != all(select tid from studentteachers where sid=${id})`;
    db.execute(statement,(error,data)=>{
        if(error){
            response.status(400).send({message:'data not inserted'});
        }
        else{
            response.status(200).send({message:data});
        }
    })

})
Router.get('/studentteachers/Amt/:id',(request,response)=>{
    const {id}=request.params;
    const statement=`select Sum(t.Price) as total from studentteachers st inner join teachers t on t.id=st.tid where sid=${id}`;
    db.execute(statement,(error,data)=>{
        if(error){
            response.status(400).send({message:'data not inserted'});
        }
        else{
            response.status(200).send({message:data});
        }
    })
})

Router.get('/studentteachers/:id',(request,response)=>{
    const {id}=request.params;
 const statement=`select t.name,t.exp,t.subject,t.rating,t.Price,t.contact from studentteachers st inner join teachers t on t.id=st.tid where st.sid=${id}`;
    db.execute(statement,(error,data)=>{
        if(error){
            response.status(400).send({message:'data not inserted'});
        }
        else{
            response.status(200).send({message:data});
        }
    })
    })
    


module.exports=Router;